﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;

namespace laboratornaya
{
    public partial class Form1 : Form
    {
        int N = 4;
        int M = 5;
        int[,] mass;
        int[,] rewmass;
        public Form1()
        {
            InitializeComponent();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            mass = new int[N, M];
            Random rnd = new Random();
            int i, j;
            dataGridView1.RowCount = N;
            dataGridView1.ColumnCount = M;

            for (i =0; i< N; ++i)
            {
                for (j = 0; j < M; ++j)
                {
                    mass[i, j] = rnd.Next(1, 10);
                    dataGridView1.Rows[i].Cells[j].Value = mass[i, j];
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView2.RowCount = N;
            dataGridView2.ColumnCount = M;
            int i, j;
            rewmass = new int[N, M];
            for (i = 0; i < N; ++i)
            {
                for (j = 0; j < M; ++j)
                {
                    int temp = mass[i, j];
                    rewmass[i, j] = mass[i, M-1-j];
                    rewmass[i, M-1-j] = temp;
                    
                }
            }
            for (i = 0; i < N; ++i)
            {
                for (j = 0; j < M; ++j)
                {
                    dataGridView2.Rows[i].Cells[j].Value = rewmass[i, j];
                }
            }
           
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
           

        
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
            Fraction frnum = new Fraction(1, 5, 1);
            DecFraction dfrnum = new DecFraction(1.005);
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DecFraction dfrnum = new DecFraction((double)numericUpDown4.Value);
            Fraction frnum = dfrnum.convertToFraction();
            label7.Text = frnum.frint.ToString();
            label8.Text = frnum.num.ToString();
            label9.Text = "----------------";
            label10.Text = frnum.denum.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Fraction frnum = new Fraction((int)numericUpDown2.Value, (int)numericUpDown3.Value, (int)numericUpDown1.Value);
            //DecFraction dfrnum = frnum.convertToDecfraction();
            //Debug.WriteLine(dfrnum);
            //label5.Text = dfrnum.num.ToString()+ "." + dfrnum.rem.ToString().Split(',')[1];
            try
            {
                Converting cnv = new Converting();

                label5.Text = cnv.Period((double)numericUpDown1.Value, (double)numericUpDown2.Value, (double)numericUpDown3.Value);

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                Converting cnv = new Converting();

                (string v1, string v2, string v3) = cnv.CNV_Period((double)numericUpDown5.Value, (int)numericUpDown6.Value);

                if (v1 == "0") label4.Text = "";
                else label4.Text = v1;

                label6.Text = v2;
                label12.Text = v3;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    public class Fraction
    {
        public int frint;
        public int num;
        public int denum;
        public int sign;

        Converting cnv = new Converting();

        public Fraction(int num, int denum, int frint = 0) { 
        if (denum == 0)
            {
                throw new DivideByZeroException("0 в знаминателе");
            }
        else
            {
                this.frint = frint;
                this.num = num;
                this.denum = denum;
                if(num*denum > 0)
                {
                    this.sign = 1;
                }
                else
                {
                    this.sign = -1;
                }
                if (num > denum)
                {
                    this.frint = frint + (num / denum);
                    this.num = num % denum;
                }
  
            }
        }

        public DecFraction convertToDecfraction()
        {
            double lendivisoin = (double) num / (double)denum ;
            string cnt = "1";
            double strdivision = num % denum;

            string result = cnv.Period(frint, num, denum);

            return new DecFraction(frint+ lendivisoin);
        }

    }

    class Converting
    {
        public string Drob(int chel, double chisl, double znamn)
        {
            if (chel >= 0)
            {
                string result = "";
                result = (chel + (chisl / znamn)).ToString();
                return result;
            }
            else
            {
                string result = "";
                result = (chel - (chisl / znamn)).ToString();
                return result;
            }
        }
        public string Period(double chel, double chisl, double znamn)
        {

            var arr = new List<int>();
            double modulo = chisl % znamn;
            int counter = 0;
            double v = modulo - 1;
            int s = Convert.ToInt32(v);
            arr.Add(s);

            while (modulo != 0)
            {
                double d = chisl / znamn;
                string sd = d.ToString();
                string[] explode = sd.Split(",".ToCharArray());
                string period = explode[1];
                for (int i = 0; i < period.Length; i++) counter++;
                if (counter > 8) break;
                if (chel > 0)
                {
                    return (chel + (chisl / znamn)).ToString() + "(0)";
                }
                else
                {
                    return (chel - (chisl / znamn)).ToString() + "(0)";
                }
            }
            if (modulo != 0)
            {
                double d = chisl / znamn;
                string sd = d.ToString();
                string[] explode = sd.Split(",".ToCharArray());
                string period = explode[1];
                int zed = arr[0];
                string zeds = zed.ToString();
                int exp = Convert.ToInt32(explode[0]);
                if (chel > 0)
                {
                    return (chel + exp).ToString() + "," + period.Substring(0, zeds.Length - 1) + '(' + period.Substring(period.Length - 1) + ')';
                }
                else
                {
                    return (chel - exp).ToString() + "," + period.Substring(0, zeds.Length - 1) + '(' + period.Substring(period.Length - 1) + ')';
                }
            }
            else
            {
                if (chel > 0)
                {
                    return (chel + (chisl / znamn)).ToString() + ",(0)";
                }
                else
                {
                    return (chel - (chisl / znamn)).ToString() + ",(0)";
                }
            }


        }

        public (string value1, string value2, string value3) CNV_Period(double numeric, int per)
        {
            string value1 = Convert.ToString(numeric);

            string value2 = Convert.ToString(per);

            //string value3 = Convert.ToString(Math.Pow(10, value2.Length));
            string value3 = "";

            for (int i = 0; i < value2.Length; i++)
            {
                value3 += "9";
            }

            return (value1, value2, value3);
        }
    }

    public class DecFraction {
        public double num;
        public double rem;
        public DecFraction(double number)
        {
            this.num = Math.Truncate(number);
            string temp = "0,"+ number.ToString().Split(',')[1];
            this.rem = Double.Parse(temp);
        }
        public Fraction convertToFraction()
        {

            int remcount = rem.ToString().Length - 2;
            int frint = 0;
            if(num > 0)
            {
                frint = (int)num;
            }
            string cnt = "1";
            for (int i = 0; i< remcount; ++i)
            {
                cnt = cnt+'0';
            }

            string strrem = rem.ToString().Split(',')[1]; 
            return new Fraction(Int32.Parse(strrem), Int32.Parse(cnt), frint);
        }
    }
    public class PerionicFraction :DecFraction
    {
        public PerionicFraction(double number): base (number)
        {
            this.num = (int)Math.Truncate(number);
            string temp = number.ToString().Split(',')[1];
            this.rem = Int32.Parse(temp) / 10;
        }
    }
}
